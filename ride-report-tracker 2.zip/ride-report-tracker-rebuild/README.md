# Ride Report Tracker — isolated rebuild

This is a **separate project**. It does not modify or replace your Data Logger app or the existing Ride Report Tracker repository.

## What it does

- Accepts the CSV exported by the Data Logger app at `POST /api/import`.
- Downloads the CSV in the browser separately (the integration example below does both).
- Parses Driver, Annotator, Date, RSU details, Drive ID, session start/end, overall duration, comments and the category-duration matrix.
- Igempotency: importing the exact same CSV bytes again is ignored.
- Builds an editable `.xlsx` workbook with the screenshot-derived A:AS (45-column) layout.
- Sorts rides chronologically by date and session start.
- Adds an orange totals row for duration columns.
- Includes a Z Frame Checker dropdown.

## Important known limitations in this first isolated build

The sample CSV contains only the ride metadata and category durations. It does **not** contain Route, State/City, Start Point, End Point, Vehicle, or Z Frame Checker status, so those cells are deliberately blank and remain editable in Excel. Dusk is supported in the workbook; when absent from the CSV it is `00:00:00`. `Day` is populated from the calendar date, and `Calendar Week` is derived from the date.

The current import protects against byte-identical duplicate uploads. If a CSV is changed and re-uploaded with the same Drive ID, it is stored as a distinct report; before production use, add a Drive-ID collision review/merge policy and database backup.

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://localhost:5000`.

## Connect Data Logger Export to this app

At the Data Logger app's CSV export function, keep the existing download behavior and add a call like this. Replace `TRACKER_URL` with your deployed tracker URL.

```javascript
async function exportRideReportAndSync(filename, csvText) {
  // 1) Preserve the user's local CSV download.
  const blob = new Blob([csvText], { type: "text/csv;charset=utf-8" });
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = objectUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(objectUrl);

  // 2) Send the same CSV to the independent Ride Report Tracker.
  const response = await fetch("https://YOUR-TRACKER-DOMAIN/api/import", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filename, csv: csvText })
  });
  if (!response.ok) throw new Error(`Tracker sync failed: ${response.status}`);
  return await response.json();
}
```

Call `exportRideReportAndSync(filename, csvText)` in the same place where the Data Logger currently creates/downloads the CSV. Keep the existing export path as a fallback if tracker sync fails; do not block the local download.

### Browser CORS

Set `LOGGER_ORIGIN` on the tracker deployment to the exact Data Logger origin if you want to restrict cross-origin calls. `*` is the default for initial testing only. If the Data Logger uses a different origin, set it explicitly.

## Deploy

This Flask project can be deployed to Render or another Python WSGI host. For a production deployment:
- Use persistent disk storage mounted at `/var/data` and set `RIDE_REPORT_DATA=/var/data`, or replace SQLite with managed PostgreSQL.
- Set `LOGGER_ORIGIN` to the Data Logger origin.
- Use HTTPS.
- Add authentication/API token protection before exposing the import endpoint publicly.
- Back up the database before upgrading.

## Test

```bash
pip install -r requirements.txt
pytest -q
```
