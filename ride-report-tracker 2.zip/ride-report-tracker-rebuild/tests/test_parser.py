from app import parse_logger_csv, HEADERS, DURATION_FIELDS, duration_seconds
from pathlib import Path

def test_screenshot_layout_is_45_columns():
    assert len(HEADERS) == 45
    assert HEADERS[17:23] == ["Sunny","Low Sun","Cloudy","Rain","Fog","Snow"]
    assert HEADERS[28:33] == ["Day","Dawn","Dusk","Lit Night","Dark Night"]
    assert HEADERS[42:45] == ["Z Frame Checker (Status)","Sanity Check-Comments","Comments"]

def test_sample_logger_csv_parses():
    raw = b"""DataLogger Report,
Driver,Wajid
Annotator,Sai
Date,07/17/26
RSU Startdate,07/17/26
RSU No,64-04
RSU Storage,10%
Drive id,050212
Session Starttime,01:02:44
Session Endtime,01:35:43
Overall Sessiontime,00:32:58
Comments,

Weather,,Road Type,,Lighting,,Traffic,,Speed,
Sunny,00:00:00,City,00:04:15,Day,00:00:00,Flow,00:32:52,3-18mph,00:00:00
Low Sun,00:00:00,Country,00:28:39,Dawn,00:00:00,Jam,00:00:00,19-37mph,00:02:27
Cloudy,00:32:58,Highway,00:00:00,Lit Night,00:04:13,,,38-55mph,00:30:24
Rain,00:00:00,Construction,00:00:00,Dark Night,00:28:37,,,56-80mph,00:00:00
Fog,00:00:00,Tunnel,00:00:00,,,,,81-155mph,00:00:00
Snow,00:00:00,,,,,,,,
"""
    _, row, _ = parse_logger_csv(raw, "ride.csv")
    assert row["Driver"] == "Wajid"
    assert row["Annotator"] == "Sai"
    assert row["Date"] == "07/17/2026"
    assert row["Drive ID"] == "050212"
    assert row["Cloudy"] == "00:32:58"
    assert row["Country"] == "00:28:39"
    assert row["Lit Night"] == "00:04:13"
    assert row["03_18 mph"] == "00:00:00"
    assert row["hh:mm"] == "00:32"
