import csv, io, os, sqlite3, hashlib
from datetime import datetime, date
from pathlib import Path
from flask import Flask, request, jsonify, send_file, render_template
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from werkzeug.utils import secure_filename

BASE = Path(os.environ.get("RIDE_REPORT_DATA", Path(__file__).parent / "data"))
BASE.mkdir(parents=True, exist_ok=True)
DB = BASE / "ride_reports.sqlite3"
XLSX = BASE / "Daily_Ride_Report_Tracker.xlsx"

# Screenshot-derived A:AS layout (A is a deliberately blank spacer column).
HEADERS = [
    "", "Driver", "Annotator", "Day", "Route", "State, City", "Start Point",
    "End Point", "Drive Cycle Start Time", "Drive Cycle End Time",
    "Calendar Week", "Date", "Vehicle", "Drive ID", "RSU Start Date",
    "RSU Storage %", "RSU Number",
    "Sunny", "Low Sun", "Cloudy", "Rain", "Fog", "Snow",
    "City (intense traffic)", "Country", "Highway", "Construction Site", "Tunnel",
    "Day", "Dawn", "Dusk", "Lit Night", "Dark Night", "Flow", "Jam",
    "03_18 mph", "18_37 mph", "37_55 mph", "55_80 mph", "81-155mph",
    "Drive cycle minutes", "hh:mm", "Z Frame Checker (Status)",
    "Sanity Check-Comments", "Comments"
]
CATEGORY_MAP = {
    "Weather": {"Sunny":"Sunny", "Low Sun":"Low Sun", "Cloudy":"Cloudy", "Rain":"Rain", "Fog":"Fog", "Snow":"Snow"},
    "Road Type": {"City":"City (intense traffic)", "Country":"Country", "Highway":"Highway", "Construction":"Construction Site", "Construction Site":"Construction Site", "Tunnel":"Tunnel"},
    "Lighting": {"Day":"Day", "Dawn":"Dawn", "Dusk":"Dusk", "Lit Night":"Lit Night", "Dark Night":"Dark Night"},
    "Traffic": {"Flow":"Flow", "Jam":"Jam"},
    "Speed": {"3-18mph":"03_18 mph", "3-18 mph":"03_18 mph", "19-37mph":"18_37 mph", "18-37mph":"18_37 mph", "37-55mph":"37_55 mph", "38-55mph":"37_55 mph", "56-80mph":"55_80 mph", "55-80mph":"55_80 mph", "81-155mph":"81-155mph"},
}
DURATION_FIELDS = [v for group in CATEGORY_MAP.values() for v in group.values()]

def duration_seconds(value):
    try:
        h,m,s = [int(x) for x in str(value or "0:0:0").split(":")]
        return h*3600 + m*60 + s
    except Exception:
        return 0

def duration_text(seconds):
    seconds = int(seconds or 0)
    h, rem = divmod(seconds, 3600); m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def parse_logger_csv(raw: bytes, filename: str):
    text = raw.decode("utf-8-sig", errors="replace")
    rows = list(csv.reader(io.StringIO(text)))
    meta = {}
    for row in rows:
        if len(row) >= 2 and row[0].strip() and row[0].strip() != "DataLogger Report":
            meta[row[0].strip()] = row[1].strip()
    # Parse category matrix by header row, not fixed column positions.
    category_values = {}
    for i, row in enumerate(rows):
        if row and row[0].strip() == "Weather":
            headers = [x.strip() for x in row]
            for data in rows[i+1:]:
                if not any(x.strip() for x in data):
                    continue
                for j in range(0, len(headers)-1, 2):
                    cat = headers[j].strip()
                    label = data[j].strip() if j < len(data) else ""
                    dur = data[j+1].strip() if j+1 < len(data) else ""
                    if cat in CATEGORY_MAP and label in CATEGORY_MAP[cat]:
                        category_values[CATEGORY_MAP[cat][label]] = dur or "00:00:00"
            break
    # Dates in sample CSV are mm/dd/yy. Preserve as display text.
    report_date = meta.get("Date", "")
    try:
        dt = datetime.strptime(report_date, "%m/%d/%y")
        date_display = dt.strftime("%m/%d/%Y")
        day_num = dt.strftime("%A")
        week = f"CW{dt.isocalendar().week:02d}"
    except ValueError:
        try:
            dt = datetime.strptime(report_date, "%m/%d/%Y")
            date_display = dt.strftime("%m/%d/%Y"); day_num = dt.strftime("%A")
            week = f"CW{dt.isocalendar().week:02d}"
        except ValueError:
            date_display = report_date; day_num = ""; week = ""
    drive_id = meta.get("Drive id", "")
    start = meta.get("Session Starttime", "")
    end = meta.get("Session Endtime", "")
    overall = meta.get("Overall Sessiontime", "")
    total = duration_seconds(overall)
    row = {h:"" for h in HEADERS}
    row.update({
        "Driver":meta.get("Driver",""), "Annotator":meta.get("Annotator",""),
        "Day":day_num, "Calendar Week":week, "Date":date_display,
        "Drive ID":drive_id, "RSU Start Date":meta.get("RSU Startdate",""),
        "RSU Storage %":meta.get("RSU Storage","").replace("%",""),
        "RSU Number":meta.get("RSU No",""),
        "Drive Cycle Start Time":start, "Drive Cycle End Time":end,
        "Drive cycle minutes":overall,
        "hh:mm":f"{total//3600:02d}:{(total%3600)//60:02d}",
        "Comments":meta.get("Comments",""),
    })
    row.update(category_values)
    digest = hashlib.sha256(raw).hexdigest()
    return digest, row, filename

def db_conn():
    conn=sqlite3.connect(DB)
    conn.row_factory=sqlite3.Row
    conn.execute("""CREATE TABLE IF NOT EXISTS reports (
        digest TEXT PRIMARY KEY, filename TEXT NOT NULL, row_json TEXT NOT NULL,
        imported_at TEXT NOT NULL)""")
    conn.commit()
    return conn

def upsert_report(raw, filename):
    digest,row,filename=parse_logger_csv(raw,filename)
    with db_conn() as conn:
        exists=conn.execute("SELECT 1 FROM reports WHERE digest=?",(digest,)).fetchone()
        if exists:
            return False, row
        # Same drive ID imported again with altered CSV: keep both versions distinct,
        # but the UI warns the operator through the response.
        conn.execute("INSERT INTO reports VALUES(?,?,?,?)",
                     (digest,filename,__import__("json").dumps(row),datetime.now().isoformat(timespec="seconds")))
    rebuild_workbook()
    return True,row

def load_rows():
    import json
    with db_conn() as conn:
        records=conn.execute("SELECT row_json FROM reports").fetchall()
    rows=[json.loads(x["row_json"]) for x in records]
    def sortkey(r):
        try: d=datetime.strptime(r.get("Date",""),"%m/%d/%Y")
        except ValueError: d=datetime.max
        return (d, r.get("Drive Cycle Start Time",""), r.get("Drive ID",""))
    return sorted(rows,key=sortkey)

def rebuild_workbook():
    wb=Workbook(); ws=wb.active; ws.title="Daily Tracker"; ws.sheet_view.showGridLines=False
    ws.append(HEADERS); ws.row_dimensions[1].height=42
    for c in ws[1]:
        c.font=Font(bold=True,color="000000")
        col=c.column
        fill=("CFE2F3" if 18<=col<=23 else "FCE4D6" if 24<=col<=28 else
              "E2F0D9" if 29<=col<=33 else "D9EAD3" if 34<=col<=35 else
              "FCE4D6" if 36<=col<=40 else "00D6A3" if col in (41,42) else
              "2CB8C4" if col==43 else "FFC000" if col in (44,45) else "D9EAD3")
        c.fill=PatternFill("solid",fgColor=fill)
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    rows=load_rows()
    for r in rows:
        ws.append([r.get(h,"") if h else "" for h in HEADERS])
    total_row=len(rows)+2
    for col,h in enumerate(HEADERS,1):
        cell=ws.cell(total_row,col)
        if h in DURATION_FIELDS or h=="Drive cycle minutes":
            cell.value=duration_text(sum(duration_seconds(r.get(h,"")) for r in rows))
        elif h=="hh:mm":
            sec=sum(duration_seconds(r.get("Drive cycle minutes","")) for r in rows)
            cell.value=f"{sec//3600:02d}:{(sec%3600)//60:02d}"
        cell.fill=PatternFill("solid",fgColor="F4B183")
        cell.font=Font(bold=True)
        cell.alignment=Alignment(horizontal="center",vertical="center")
    thin=Side(style="thin",color="808080")
    for row in ws.iter_rows(min_row=1,max_row=total_row,min_col=1,max_col=45):
        for cell in row:
            cell.border=Border(left=thin,right=thin,top=thin,bottom=thin)
            if cell.row>1 and cell.row<total_row:
                cell.alignment=Alignment(horizontal="left" if cell.column in (2,3,6,7,8,14,44,45) else "center",vertical="center",wrap_text=True)
    widths={1:3,2:16,3:15,4:8,5:8,6:18,7:34,8:34,9:17,10:17,11:12,12:13,13:14,14:28,15:14,16:12,17:12,43:20,44:42,45:58}
    for col in range(1,46): ws.column_dimensions[get_column_letter(col)].width=widths.get(col,12)
    ws.freeze_panes="B2"
    ws.auto_filter.ref=f"A1:AS{max(1,total_row-1)}"
    dv=DataValidation(type="list",formula1='"Passed,Failed,Repairable"',allow_blank=True)
    ws.add_data_validation(dv); dv.add("AQ2:AQ1048576")
    wb.save(XLSX)

app=Flask(__name__)
@app.get("/")
def home():
    return render_template("index.html", count=len(load_rows()))

@app.post("/api/import")
def import_csv():
    # CORS preflight is supported for Data Logger app -> tracker.
    if "file" in request.files:
        f=request.files["file"]; raw=f.read(); filename=secure_filename(f.filename or "ride-report.csv")
    else:
        payload=request.get_json(silent=True) or {}
        filename=secure_filename(payload.get("filename") or "ride-report.csv")
        content=payload.get("csv") or ""
        if not content: return jsonify(ok=False,error="CSV content is missing"),400
        raw=content.encode("utf-8-sig")
    if not raw.strip(): return jsonify(ok=False,error="CSV file is empty"),400
    try:
        created,row=upsert_report(raw,filename)
        return jsonify(ok=True,created=created,duplicate=not created,drive_id=row.get("Drive ID"),date=row.get("Date"),message="Imported" if created else "Already imported; duplicate ignored")
    except Exception as exc:
        return jsonify(ok=False,error=str(exc)),400

@app.route("/api/import",methods=["OPTIONS"])
def import_options():
    return ("",204)

@app.after_request
def cors(response):
    response.headers["Access-Control-Allow-Origin"]=os.environ.get("LOGGER_ORIGIN","*")
    response.headers["Access-Control-Allow-Headers"]="Content-Type"
    response.headers["Access-Control-Allow-Methods"]="GET,POST,OPTIONS"
    return response

@app.get("/api/status")
def status():
    return jsonify(ok=True,records=len(load_rows()))

@app.get("/download")
def download():
    rebuild_workbook()
    return send_file(XLSX,as_attachment=True,download_name="Daily_Ride_Report_Tracker.xlsx")

@app.post("/api/rebuild")
def rebuild():
    rebuild_workbook()
    return jsonify(ok=True,records=len(load_rows()),file="/download")

if __name__=="__main__":
    rebuild_workbook()
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","5000")),debug=False)
